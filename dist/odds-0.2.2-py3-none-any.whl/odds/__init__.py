"""
__init__.py file to allow the files in this folder to be imported in to other folders.
"""
from .odds import OD
